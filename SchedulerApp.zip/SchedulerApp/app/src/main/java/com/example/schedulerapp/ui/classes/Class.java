package com.example.schedulerapp.ui.classes;

public class Class {
    private String name;
    private String day;
    private String instructor;

    public Class(String name, String day, String instructor) {
        this.name = name;
        this.day = day;
        this.instructor = instructor;
    }
    public String getCourseName() {
        return name;
    }
    public String getDay() {
        return day;
    }
    public String getInstructor() {
        return instructor;
    }
}
