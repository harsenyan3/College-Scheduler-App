package com.example.schedulerapp.ui.exams;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.schedulerapp.R;
import com.example.schedulerapp.ui.exams.ExamAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class exams extends Fragment {
    ListView lvexam;
    EditText etcourse;
    EditText etdate;
    EditText etlocation;
    Button addbtn;
    Button updatebtn;
    Button deletebtn;
    Button clearbtn;
    ArrayList<Exam> exams = new ArrayList<Exam>();
    ExamAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_exams, container, false);
        lvexam = (ListView) view.findViewById(R.id.examlistview);
        etcourse = (EditText) view.findViewById(R.id.editexamcourse);
        etdate = (EditText) view.findViewById(R.id.editexamdate);
        etlocation = (EditText) view.findViewById(R.id.editexamlocation);
        addbtn = (Button) view.findViewById(R.id.addbtn);
        updatebtn = (Button) view.findViewById(R.id.updatebtn);
        deletebtn = (Button) view.findViewById(R.id.deletebtn);
        clearbtn = (Button) view.findViewById(R.id.clearbtn);
        adapter = new ExamAdapter(requireContext(),android.R.layout.simple_list_item_single_choice, exams);
        lvexam.setAdapter(adapter);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClass();
            }
        });

        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateClass();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteClass();
            }
        });

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearClasses();
            }
        });
        return view;
    }

    private void addClass() {
        String courseName = etcourse.getText().toString();
        String day = etdate.getText().toString();
        String instructor = etlocation.getText().toString();

        if (!courseName.isEmpty() && !day.isEmpty() && !instructor.isEmpty()) {
            Exam newClass = new Exam(courseName, day, instructor);
            exams.add(newClass);
            adapter.notifyDataSetChanged();
            clearInputFields();
        } else {
            Toast.makeText(getActivity(), "Please input all fields!", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateClass() {
        int selectedPosition = lvexam.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            String updatedCourseName = etcourse.getText().toString();
            String updatedDay = etdate.getText().toString();
            String updatedInstructor = etlocation.getText().toString();

            if (!updatedCourseName.isEmpty() && !updatedDay.isEmpty() && !updatedInstructor.isEmpty()) {
                Exam updatedClass = new Exam(updatedCourseName, updatedDay, updatedInstructor);
                exams.set(selectedPosition, updatedClass);
                adapter.notifyDataSetChanged();
                clearInputFields();
                lvexam.clearChoices(); // Clear the selected item
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(requireContext(), "Select a class to update", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteClass() {
        int selectedPosition = lvexam.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            exams.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            clearInputFields();
            lvexam.clearChoices(); // Clear the selected item
        } else {
            Toast.makeText(requireContext(), "Select a class to delete!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearClasses() {
        exams.clear();
        adapter.notifyDataSetChanged();
        clearInputFields();
        lvexam.clearChoices(); // Clear the selected item
    }
    private void clearInputFields() {
        etcourse.setText("");
        etdate.setText("");
        etlocation.setText("");
    }
}
