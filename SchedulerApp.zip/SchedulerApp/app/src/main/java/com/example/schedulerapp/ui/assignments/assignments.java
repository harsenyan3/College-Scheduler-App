package com.example.schedulerapp.ui.assignments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.schedulerapp.R;
import com.example.schedulerapp.ui.exams.Exam;
import com.example.schedulerapp.ui.exams.ExamAdapter;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class assignments extends Fragment {

    ListView lvassignment;
    EditText ettitle;
    EditText etdate;
    EditText etcourse;
    Button addbtn;
    Button updatebtn;
    Button deletebtn;
    Button clearbtn;
    Button sortbtn;
    Button sort2btn;
    ArrayList<Assignment> assignments = new ArrayList<Assignment>();
    AssignmentAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_assignments, container, false);
        lvassignment = (ListView) view.findViewById(R.id.todolistview1);
        ettitle = (EditText) view.findViewById(R.id.editassignmentstitle);
        etdate = (EditText) view.findViewById(R.id.editassignmentsdate);
        etcourse = (EditText) view.findViewById(R.id.editassignmentsclass);
        addbtn = (Button) view.findViewById(R.id.addbtn);
        updatebtn = (Button) view.findViewById(R.id.updatebtn);
        deletebtn = (Button) view.findViewById(R.id.deletebtn);
        clearbtn = (Button) view.findViewById(R.id.clearbtn);
        sortbtn = (Button) view.findViewById(R.id.sortbtn);
        sort2btn = (Button) view.findViewById(R.id.sort2btn);
        adapter = new AssignmentAdapter(requireContext(),android.R.layout.simple_list_item_single_choice, assignments);
        lvassignment.setAdapter(adapter);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClass();
            }
        });

        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateClass();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteClass();
            }
        });

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearClasses();
            }
        });

        sortbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SortClassesAtoZ();
                adapter.notifyDataSetChanged();
            }
        });

        sort2btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SortClassesDue();
                adapter.notifyDataSetChanged();
            }
        });

        return view;
    }

    private void addClass() {
        String title = ettitle.getText().toString();
        String date = etdate.getText().toString();
        String course = etcourse.getText().toString();

        if (!title.isEmpty() && !date.isEmpty() && !course.isEmpty()) {
            Assignment newClass = new Assignment(title, date, course);
            assignments.add(newClass);
            adapter.notifyDataSetChanged();
            clearInputFields();
        } else {
            Toast.makeText(getActivity(), "Please input all fields!", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateClass() {
        int selectedPosition = lvassignment.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            String updatedTitle = ettitle.getText().toString();
            String updatedDate = etdate.getText().toString();
            String updatedCourse = etcourse.getText().toString();

            if (!updatedCourse.isEmpty() && !updatedDate.isEmpty() && !updatedTitle.isEmpty()) {
                Assignment updatedClass = new Assignment(updatedTitle, updatedDate, updatedCourse);
                assignments.set(selectedPosition, updatedClass);
                adapter.notifyDataSetChanged();
                clearInputFields();
                lvassignment.clearChoices(); // Clear the selected item
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(requireContext(), "Select a class to update", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteClass() {
        int selectedPosition = lvassignment.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            assignments.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            clearInputFields();
            lvassignment.clearChoices(); // Clear the selected item
        } else {
            Toast.makeText(requireContext(), "Select a class to delete!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearClasses() {
        assignments.clear();
        adapter.notifyDataSetChanged();
        clearInputFields();
        lvassignment.clearChoices(); // Clear the selected item
    }

    private void SortClassesAtoZ() {

        if (assignments.size() == 0) {
            Toast.makeText(requireContext(), "There are no classes to sort!", Toast.LENGTH_SHORT).show();
        } else {
            assignments.sort(new Comparator<Assignment>() {
                @Override
                public int compare(Assignment class1, Assignment class2) {
                    return class1.getCourseName().compareToIgnoreCase(class2.getCourseName());
                }
            });
        }
    }

    private void SortClassesDue() {

        if (assignments.size() == 0) {
            Toast.makeText(requireContext(), "There are no classes to sort!", Toast.LENGTH_SHORT).show();
        } else {
            assignments.sort(new Comparator<Assignment>() {
                @Override
                public int compare(Assignment class1, Assignment class2) {
                    return class1.getDate().compareToIgnoreCase(class2.getDate());
                }
            });
        }
    }
    private void clearInputFields() {
        ettitle.setText("");
        etdate.setText("");
        etcourse.setText("");
    }
}