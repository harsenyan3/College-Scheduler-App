package com.example.schedulerapp.ui.classes;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import com.example.schedulerapp.R;
import java.util.ArrayList;
import android.content.Context;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ClassAdapter extends ArrayAdapter<Class> {
    private Context mContext;
    private int mResource;

    public ClassAdapter(Context context, int resource, ArrayList<Class> classList) {
        super(context, resource, classList);
        this.mContext = context;
        this.mResource = resource;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_row, parent, false);
        }

        Class currentClass = getItem(position);

        TextView courseNameTextView = convertView.findViewById(R.id.field1);
        TextView dayOfWeekTextView = convertView.findViewById(R.id.field2);
        TextView instructorTextView = convertView.findViewById(R.id.field3);

        if (currentClass != null) {
            courseNameTextView.setText(currentClass.getCourseName());
            dayOfWeekTextView.setText(currentClass.getDay());
            instructorTextView.setText(currentClass.getInstructor());
        }

        return convertView;
    }
}
