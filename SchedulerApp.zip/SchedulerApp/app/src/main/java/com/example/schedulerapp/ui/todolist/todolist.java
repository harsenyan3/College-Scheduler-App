package com.example.schedulerapp.ui.todolist;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.schedulerapp.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class todolist extends Fragment {
    ListView taskListView;
    EditText taskName;
    Button addbtn;
    Button updatebtn;
    Button deletebtn;
    Button clearbtn;
    ArrayList<String> tasks = new ArrayList<String>();
    ArrayAdapter<String> adapter;


    public todolist() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_todolist, container, false);
        taskListView = (ListView) view.findViewById(R.id.todolistview1);
        taskName = (EditText) view.findViewById(R.id.edittodolist);
        addbtn = (Button) view.findViewById(R.id.addbtn);
        updatebtn = (Button) view.findViewById(R.id.updatebtn);
        deletebtn = (Button) view.findViewById(R.id.deletebtn);
        clearbtn = (Button) view.findViewById(R.id.clearbtn);
        adapter = new ArrayAdapter<String>(requireContext(),android.R.layout.simple_list_item_multiple_choice, tasks);
        taskListView.setAdapter(adapter);

        taskListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                taskName.setText(tasks.get(position));
            }
        });
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update();
            }
        });
        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete();
            }
        });
        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });
        return view;
    }


    private void add() {
        String task = taskName.getText().toString();

        if (task == null || task.equals("")) {
            Toast.makeText(getActivity(), "The input is empty", Toast.LENGTH_SHORT).show();
        } else if (tasks.contains(task)) {
            Toast.makeText(getActivity(), "Already exists in the list", Toast.LENGTH_SHORT).show();
        } else if (!(task == null) && task.length() > 0) {
            adapter.add(task);
            adapter.notifyDataSetChanged();
            Toast.makeText(getActivity(), "Input Added", Toast.LENGTH_SHORT).show();
            taskName.setText("");
        }
    }

    private void update() {
        String task = taskName.getText().toString();
        int position = taskListView.getCheckedItemPosition();

        if (!(task == null) && task.length() > 0) {
            adapter.remove(tasks.get(position));
            adapter.insert(task, position);
            adapter.notifyDataSetChanged();
            Toast.makeText(getActivity(), "Input Updated", Toast.LENGTH_SHORT).show();
            taskName.setText("");
        } else {
            Toast.makeText(getActivity(), "The Update is empty", Toast.LENGTH_SHORT).show();
        }
    }

    private void delete() {
        int position = taskListView.getCheckedItemPosition();
        if (position > -1) {
            adapter.remove(tasks.get(position));
            adapter.notifyDataSetChanged();
            taskName.setText("");
            Toast.makeText(getActivity(), "Input Deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Select input to delete", Toast.LENGTH_SHORT).show();
        }
    }

    private void clear() {
        if (tasks.size() == 0) {
            Toast.makeText(getActivity(), "Nothing to clear", Toast.LENGTH_SHORT).show();
        } else {
            adapter.clear();
            adapter.notifyDataSetChanged();
        }
    }


}