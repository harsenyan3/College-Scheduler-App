package com.example.schedulerapp.ui.classes;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.schedulerapp.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class classes extends Fragment {
    ListView lvclass;
    EditText etcourse;
    EditText etday;
    EditText etinstructor;
    Button addbtn;
    Button updatebtn;
    Button deletebtn;
    Button clearbtn;
    ArrayList<Class> classes = new ArrayList<Class>();
    ClassAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_classes, container, false);
        lvclass = (ListView) view.findViewById(R.id.todolistview1);
        etcourse = (EditText) view.findViewById(R.id.editclassescourse);
        etday = (EditText) view.findViewById(R.id.editclassesday);
        etinstructor = (EditText) view.findViewById(R.id.editclassesinstructor);
        addbtn = (Button) view.findViewById(R.id.addbtn);
        updatebtn = (Button) view.findViewById(R.id.updatebtn);
        deletebtn = (Button) view.findViewById(R.id.deletebtn);
        clearbtn = (Button) view.findViewById(R.id.clearbtn);
        adapter = new ClassAdapter(requireContext(),android.R.layout.simple_list_item_single_choice, classes);
        lvclass.setAdapter(adapter);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClass();
            }
        });

        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateClass();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteClass();
            }
        });

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearClasses();
            }
        });
        return view;
    }

    private void addClass() {
        String courseName = etcourse.getText().toString();
        String day = etday.getText().toString();
        String instructor = etinstructor.getText().toString();

        if (!courseName.isEmpty() && !day.isEmpty() && !instructor.isEmpty()) {
            Class newClass = new Class(courseName, day, instructor);
            classes.add(newClass);
            adapter.notifyDataSetChanged();
            clearInputFields();
        } else {
            Toast.makeText(getActivity(), "Please input all fields!", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateClass() {
        int selectedPosition = lvclass.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            String updatedCourseName = etcourse.getText().toString();
            String updatedDay = etday.getText().toString();
            String updatedInstructor = etinstructor.getText().toString();

            if (!updatedCourseName.isEmpty() && !updatedDay.isEmpty() && !updatedInstructor.isEmpty()) {
                Class updatedClass = new Class(updatedCourseName, updatedDay, updatedInstructor);
                classes.set(selectedPosition, updatedClass);
                adapter.notifyDataSetChanged();
                clearInputFields();
                lvclass.clearChoices(); // Clear the selected item
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(requireContext(), "Select a class to update", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteClass() {
        int selectedPosition = lvclass.getCheckedItemPosition();

        if (selectedPosition != ListView.INVALID_POSITION) {
            classes.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            clearInputFields();
            lvclass.clearChoices(); // Clear the selected item
        } else {
            Toast.makeText(requireContext(), "Select a class to delete!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearClasses() {
        classes.clear();
        adapter.notifyDataSetChanged();
        clearInputFields();
        lvclass.clearChoices(); // Clear the selected item
    }
        private void clearInputFields() {
        etcourse.setText("");
        etday.setText("");
        etinstructor.setText("");
    }
}
