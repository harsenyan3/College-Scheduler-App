package com.example.schedulerapp.ui.assignments;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.schedulerapp.R;
import com.example.schedulerapp.ui.assignments.Assignment;

import java.util.ArrayList;

public class AssignmentAdapter extends ArrayAdapter<Assignment> {

    public AssignmentAdapter(Context context, int resource, ArrayList<Assignment> classList) {
        super(context, resource, classList);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_row, parent, false);
        }

        Assignment currentClass = getItem(position);

        TextView TitleTextView = convertView.findViewById(R.id.field1);
        TextView dateTextView = convertView.findViewById(R.id.field2);
        TextView courseNameView = convertView.findViewById(R.id.field3);

        if (currentClass != null) {
            TitleTextView.setText(currentClass.getTitle());
            dateTextView.setText(currentClass.getDate());
            courseNameView.setText(currentClass.getCourseName());
        }

        return convertView;
    }
}
