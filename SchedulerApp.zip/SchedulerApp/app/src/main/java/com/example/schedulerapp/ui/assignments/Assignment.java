package com.example.schedulerapp.ui.assignments;

public class Assignment {
    private String title;
    private String date;
    private String course;

    public Assignment(String name, String date, String instructor) {
        this.title = name;
        this.date = date;
        this.course = instructor;
    }
    public String getCourseName() {
        return course;
    }
    public String getDate() {
        return date;
    }
    public String getTitle() {
        return title;
    }
}
