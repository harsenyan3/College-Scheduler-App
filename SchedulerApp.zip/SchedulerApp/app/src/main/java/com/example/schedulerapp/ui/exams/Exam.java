package com.example.schedulerapp.ui.exams;

public class Exam {
    private String course;
    private String date;
    private String location;

    public Exam(String name, String day, String instructor) {
        this.course = name;
        this.date = day;
        this.location = instructor;
    }
    public String getCourseName() {
        return course;
    }
    public String getDay() {
        return date;
    }
    public String getInstructor() {
        return location;
    }
}
